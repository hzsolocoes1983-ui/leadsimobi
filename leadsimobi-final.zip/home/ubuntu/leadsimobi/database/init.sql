COPY /home/ubuntu/leadsimobi/database/schema.sql;
COPY /home/ubuntu/leadsimobi/database/sales_schema.sql;
COPY /home/ubuntu/leadsimobi/database/clients_schema.sql;
