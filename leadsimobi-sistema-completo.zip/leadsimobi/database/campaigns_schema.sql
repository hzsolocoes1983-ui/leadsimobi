-- =====================================================
-- SCHEMA: CAMPANHAS E ENVIO EM MASSA
-- Descrição: Tabelas para gerenciar campanhas de marketing,
--            envio em massa e automações
-- =====================================================

-- Tabela de Campanhas
CREATE TABLE IF NOT EXISTS campaigns (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    type VARCHAR(50) NOT NULL CHECK (type IN ('broadcast', 'drip', 'automation')),
    status VARCHAR(50) DEFAULT 'draft' CHECK (status IN ('draft', 'scheduled', 'running', 'paused', 'completed', 'cancelled')),
    
    -- Canais
    channels JSONB DEFAULT '[]'::jsonb, -- ['whatsapp', 'instagram', 'facebook']
    
    -- Segmentação
    target_audience VARCHAR(50) CHECK (target_audience IN ('all', 'segment', 'custom')),
    segment_filters JSONB, -- Filtros de segmentação
    contact_list_ids UUID[], -- IDs de listas de contatos
    total_recipients INTEGER DEFAULT 0,
    
    -- Mensagem
    message_template_id UUID,
    message_content TEXT,
    media_urls TEXT[],
    variables JSONB, -- Variáveis para personalização
    
    -- Agendamento
    schedule_type VARCHAR(50) CHECK (schedule_type IN ('immediate', 'scheduled', 'recurring')),
    scheduled_at TIMESTAMP,
    recurring_pattern VARCHAR(100), -- Ex: "daily", "weekly", "monthly"
    timezone VARCHAR(50) DEFAULT 'America/Sao_Paulo',
    
    -- Controle de taxa
    rate_limit_enabled BOOLEAN DEFAULT true,
    messages_per_minute INTEGER DEFAULT 20,
    messages_per_hour INTEGER DEFAULT 1000,
    delay_between_messages INTEGER DEFAULT 3, -- segundos
    
    -- Resultados
    sent_count INTEGER DEFAULT 0,
    delivered_count INTEGER DEFAULT 0,
    read_count INTEGER DEFAULT 0,
    replied_count INTEGER DEFAULT 0,
    failed_count INTEGER DEFAULT 0,
    opt_out_count INTEGER DEFAULT 0,
    
    -- Conversão
    leads_generated INTEGER DEFAULT 0,
    conversions INTEGER DEFAULT 0,
    conversion_value DECIMAL(15,2) DEFAULT 0,
    
    -- Custo e ROI
    cost DECIMAL(15,2) DEFAULT 0,
    roi DECIMAL(10,2), -- Calculado automaticamente
    
    -- Metadados
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    
    -- Configurações avançadas
    settings JSONB DEFAULT '{}'::jsonb
);

-- Tabela de Listas de Contatos
CREATE TABLE IF NOT EXISTS contact_lists (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    type VARCHAR(50) CHECK (type IN ('static', 'dynamic')),
    
    -- Filtros para listas dinâmicas
    dynamic_filters JSONB,
    
    -- Estatísticas
    total_contacts INTEGER DEFAULT 0,
    active_contacts INTEGER DEFAULT 0,
    
    -- Metadados
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    tags TEXT[]
);

-- Tabela de Contatos nas Listas
CREATE TABLE IF NOT EXISTS contact_list_members (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    contact_list_id UUID REFERENCES contact_lists(id) ON DELETE CASCADE,
    lead_id UUID REFERENCES leads(id) ON DELETE CASCADE,
    
    -- Status
    status VARCHAR(50) DEFAULT 'active' CHECK (status IN ('active', 'unsubscribed', 'bounced', 'invalid')),
    
    -- Personalização
    custom_fields JSONB,
    
    -- Metadados
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    added_by UUID REFERENCES users(id),
    
    UNIQUE(contact_list_id, lead_id)
);

-- Tabela de Mensagens Enviadas (Broadcast)
CREATE TABLE IF NOT EXISTS broadcast_messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    campaign_id UUID REFERENCES campaigns(id) ON DELETE CASCADE,
    lead_id UUID REFERENCES leads(id),
    channel_id UUID REFERENCES channels(id),
    
    -- Conteúdo
    message_content TEXT NOT NULL,
    media_urls TEXT[],
    personalized_content TEXT, -- Conteúdo após personalização
    
    -- Status de envio
    status VARCHAR(50) DEFAULT 'pending' CHECK (status IN ('pending', 'queued', 'sending', 'sent', 'delivered', 'read', 'failed', 'cancelled')),
    
    -- Timestamps
    queued_at TIMESTAMP,
    sent_at TIMESTAMP,
    delivered_at TIMESTAMP,
    read_at TIMESTAMP,
    failed_at TIMESTAMP,
    
    -- Erro
    error_message TEXT,
    error_code VARCHAR(50),
    retry_count INTEGER DEFAULT 0,
    max_retries INTEGER DEFAULT 3,
    
    -- Resposta
    replied BOOLEAN DEFAULT false,
    reply_at TIMESTAMP,
    reply_content TEXT,
    
    -- Conversão
    converted BOOLEAN DEFAULT false,
    conversion_value DECIMAL(15,2),
    
    -- Opt-out
    opted_out BOOLEAN DEFAULT false,
    opted_out_at TIMESTAMP,
    
    -- Metadados
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    metadata JSONB
);

-- Tabela de Templates de Mensagem
CREATE TABLE IF NOT EXISTS message_templates (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    category VARCHAR(100),
    
    -- Conteúdo
    content TEXT NOT NULL,
    media_urls TEXT[],
    
    -- Variáveis disponíveis
    variables TEXT[], -- Ex: ['nome', 'imovel', 'preco']
    
    -- Canal
    channels VARCHAR(50)[] DEFAULT ARRAY['whatsapp'], -- Quais canais suportam
    
    -- Uso
    usage_count INTEGER DEFAULT 0,
    last_used_at TIMESTAMP,
    
    -- Performance
    avg_response_rate DECIMAL(5,2),
    avg_conversion_rate DECIMAL(5,2),
    
    -- Metadados
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT true,
    
    tags TEXT[]
);

-- Tabela de Automações
CREATE TABLE IF NOT EXISTS automations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    type VARCHAR(50) CHECK (type IN ('welcome', 'follow_up', 'nurture', 'reengagement', 'custom')),
    
    -- Trigger (gatilho)
    trigger_type VARCHAR(50) CHECK (trigger_type IN ('new_lead', 'tag_added', 'stage_changed', 'time_based', 'action_based', 'manual')),
    trigger_config JSONB,
    
    -- Condições
    conditions JSONB, -- Condições para executar
    
    -- Ações
    actions JSONB, -- Array de ações a executar
    
    -- Fluxo
    workflow_steps JSONB, -- Passos do fluxo de automação
    
    -- Status
    status VARCHAR(50) DEFAULT 'active' CHECK (status IN ('active', 'paused', 'archived')),
    
    -- Estatísticas
    total_triggered INTEGER DEFAULT 0,
    total_completed INTEGER DEFAULT 0,
    total_failed INTEGER DEFAULT 0,
    conversion_rate DECIMAL(5,2),
    
    -- Metadados
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    tags TEXT[]
);

-- Tabela de Execuções de Automação
CREATE TABLE IF NOT EXISTS automation_executions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    automation_id UUID REFERENCES automations(id) ON DELETE CASCADE,
    lead_id UUID REFERENCES leads(id),
    
    -- Status
    status VARCHAR(50) DEFAULT 'running' CHECK (status IN ('pending', 'running', 'completed', 'failed', 'cancelled')),
    current_step INTEGER DEFAULT 0,
    
    -- Timestamps
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP,
    
    -- Resultado
    result JSONB,
    error_message TEXT,
    
    -- Metadados
    metadata JSONB
);

-- Tabela de Métricas de Campanha (agregadas)
CREATE TABLE IF NOT EXISTS campaign_metrics (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    campaign_id UUID REFERENCES campaigns(id) ON DELETE CASCADE,
    date DATE NOT NULL,
    
    -- Envios
    messages_sent INTEGER DEFAULT 0,
    messages_delivered INTEGER DEFAULT 0,
    messages_read INTEGER DEFAULT 0,
    messages_failed INTEGER DEFAULT 0,
    
    -- Engajamento
    replies_received INTEGER DEFAULT 0,
    opt_outs INTEGER DEFAULT 0,
    
    -- Conversão
    leads_generated INTEGER DEFAULT 0,
    conversions INTEGER DEFAULT 0,
    conversion_value DECIMAL(15,2) DEFAULT 0,
    
    -- Taxas
    delivery_rate DECIMAL(5,2),
    open_rate DECIMAL(5,2),
    response_rate DECIMAL(5,2),
    conversion_rate DECIMAL(5,2),
    
    -- Custo
    cost DECIMAL(15,2) DEFAULT 0,
    roi DECIMAL(10,2),
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE(campaign_id, date)
);

-- Índices para performance
CREATE INDEX idx_campaigns_status ON campaigns(status);
CREATE INDEX idx_campaigns_created_by ON campaigns(created_by);
CREATE INDEX idx_campaigns_scheduled_at ON campaigns(scheduled_at);

CREATE INDEX idx_broadcast_messages_campaign ON broadcast_messages(campaign_id);
CREATE INDEX idx_broadcast_messages_lead ON broadcast_messages(lead_id);
CREATE INDEX idx_broadcast_messages_status ON broadcast_messages(status);
CREATE INDEX idx_broadcast_messages_sent_at ON broadcast_messages(sent_at);

CREATE INDEX idx_contact_list_members_list ON contact_list_members(contact_list_id);
CREATE INDEX idx_contact_list_members_lead ON contact_list_members(lead_id);

CREATE INDEX idx_automation_executions_automation ON automation_executions(automation_id);
CREATE INDEX idx_automation_executions_lead ON automation_executions(lead_id);
CREATE INDEX idx_automation_executions_status ON automation_executions(status);

CREATE INDEX idx_campaign_metrics_campaign_date ON campaign_metrics(campaign_id, date);

-- Triggers para atualizar timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_campaigns_updated_at BEFORE UPDATE ON campaigns
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_contact_lists_updated_at BEFORE UPDATE ON contact_lists
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_message_templates_updated_at BEFORE UPDATE ON message_templates
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_automations_updated_at BEFORE UPDATE ON automations
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Função para calcular ROI
CREATE OR REPLACE FUNCTION calculate_campaign_roi()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.cost > 0 AND NEW.conversion_value > 0 THEN
        NEW.roi = ((NEW.conversion_value - NEW.cost) / NEW.cost) * 100;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER calculate_campaign_roi_trigger BEFORE INSERT OR UPDATE ON campaigns
    FOR EACH ROW EXECUTE FUNCTION calculate_campaign_roi();

-- View: Resumo de Campanhas
CREATE OR REPLACE VIEW campaign_summary AS
SELECT 
    c.id,
    c.name,
    c.type,
    c.status,
    c.total_recipients,
    c.sent_count,
    c.delivered_count,
    c.read_count,
    c.replied_count,
    CASE 
        WHEN c.sent_count > 0 THEN ROUND((c.delivered_count::DECIMAL / c.sent_count) * 100, 2)
        ELSE 0
    END as delivery_rate,
    CASE 
        WHEN c.delivered_count > 0 THEN ROUND((c.read_count::DECIMAL / c.delivered_count) * 100, 2)
        ELSE 0
    END as open_rate,
    CASE 
        WHEN c.sent_count > 0 THEN ROUND((c.replied_count::DECIMAL / c.sent_count) * 100, 2)
        ELSE 0
    END as response_rate,
    CASE 
        WHEN c.sent_count > 0 THEN ROUND((c.conversions::DECIMAL / c.sent_count) * 100, 2)
        ELSE 0
    END as conversion_rate,
    c.cost,
    c.conversion_value,
    c.roi,
    c.created_at,
    c.started_at,
    c.completed_at,
    u.name as created_by_name
FROM campaigns c
LEFT JOIN users u ON c.created_by = u.id;

-- Comentários
COMMENT ON TABLE campaigns IS 'Campanhas de marketing e envio em massa';
COMMENT ON TABLE contact_lists IS 'Listas de contatos para segmentação';
COMMENT ON TABLE broadcast_messages IS 'Mensagens enviadas em campanhas';
COMMENT ON TABLE message_templates IS 'Templates de mensagens reutilizáveis';
COMMENT ON TABLE automations IS 'Automações de marketing';
COMMENT ON TABLE automation_executions IS 'Execuções de automações';
COMMENT ON TABLE campaign_metrics IS 'Métricas agregadas de campanhas';
