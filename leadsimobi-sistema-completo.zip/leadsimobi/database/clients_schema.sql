-- ============================================
-- MÓDULO DE CADASTRO DE CLIENTES
-- Sistema completo de cadastro, documentação e análise de crédito
-- ============================================

-- ============================================
-- TABELA: clients (Clientes Completos)
-- ============================================
CREATE TABLE IF NOT EXISTS clients (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    lead_id UUID REFERENCES leads(id), -- Relacionamento com lead
    
    -- Dados Pessoais
    full_name VARCHAR(255) NOT NULL,
    cpf VARCHAR(14) UNIQUE NOT NULL,
    rg VARCHAR(20),
    rg_issuer VARCHAR(50), -- Órgão emissor
    rg_issue_date DATE,
    birth_date DATE NOT NULL,
    nationality VARCHAR(100) DEFAULT 'Brasileira',
    marital_status VARCHAR(50), -- 'solteiro', 'casado', 'divorciado', 'viúvo', 'união estável'
    gender VARCHAR(20),
    
    -- Dados do Cônjuge (se casado)
    spouse_name VARCHAR(255),
    spouse_cpf VARCHAR(14),
    spouse_rg VARCHAR(20),
    spouse_birth_date DATE,
    spouse_phone VARCHAR(20),
    
    -- Contato
    email VARCHAR(255),
    phone VARCHAR(20) NOT NULL,
    phone_secondary VARCHAR(20),
    whatsapp VARCHAR(20),
    
    -- Endereço Atual
    address_street VARCHAR(255),
    address_number VARCHAR(20),
    address_complement VARCHAR(100),
    address_neighborhood VARCHAR(100),
    address_city VARCHAR(100),
    address_state VARCHAR(2),
    address_zip_code VARCHAR(10),
    residence_type VARCHAR(50), -- 'própria', 'alugada', 'financiada', 'cedida'
    time_at_residence INTEGER, -- Tempo em meses
    
    -- Dados Profissionais
    occupation VARCHAR(255),
    company_name VARCHAR(255),
    company_cnpj VARCHAR(18),
    company_phone VARCHAR(20),
    employment_type VARCHAR(50), -- 'CLT', 'autônomo', 'empresário', 'aposentado', 'outros'
    time_at_job INTEGER, -- Tempo em meses
    monthly_income DECIMAL(12, 2),
    other_income DECIMAL(12, 2),
    other_income_source VARCHAR(255),
    
    -- Dados do Cônjuge - Profissional
    spouse_occupation VARCHAR(255),
    spouse_company VARCHAR(255),
    spouse_monthly_income DECIMAL(12, 2),
    
    -- Dependentes
    dependents_count INTEGER DEFAULT 0,
    dependents_details JSONB, -- Array com dados dos dependentes
    
    -- Referências Pessoais
    references JSONB, -- Array com nome, telefone, relação
    
    -- Status do Cadastro
    registration_status VARCHAR(50) DEFAULT 'incomplete', 
    -- 'incomplete', 'pending_docs', 'under_analysis', 'approved', 'rejected', 'active'
    
    -- Controle
    created_by UUID REFERENCES users(id),
    assigned_to UUID REFERENCES users(id),
    notes TEXT,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- TABELA: client_documents (Documentos do Cliente)
-- ============================================
CREATE TABLE IF NOT EXISTS client_documents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    client_id UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    
    -- Tipo de Documento
    document_type VARCHAR(100) NOT NULL,
    -- 'rg_frente', 'rg_verso', 'cpf', 'comprovante_residencia', 'comprovante_renda',
    -- 'certidao_casamento', 'certidao_nascimento', 'ctps', 'ir', 'extrato_bancario', 'outros'
    
    document_name VARCHAR(255) NOT NULL,
    description TEXT,
    
    -- Arquivo
    file_url TEXT NOT NULL,
    file_type VARCHAR(50), -- 'pdf', 'jpg', 'png', etc
    file_size INTEGER, -- Em bytes
    
    -- Status
    status VARCHAR(50) DEFAULT 'pending',
    -- 'pending', 'under_review', 'approved', 'rejected', 'expired'
    
    rejection_reason TEXT,
    
    -- Validade
    issue_date DATE,
    expiry_date DATE,
    is_expired BOOLEAN GENERATED ALWAYS AS (expiry_date < CURRENT_DATE) STORED,
    
    -- Controle
    uploaded_by UUID REFERENCES users(id),
    reviewed_by UUID REFERENCES users(id),
    reviewed_at TIMESTAMP,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- TABELA: credit_analysis (Análise de Crédito)
-- ============================================
CREATE TABLE IF NOT EXISTS credit_analysis (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    client_id UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    
    -- Informações de Crédito
    credit_score INTEGER, -- Score de crédito (0-1000)
    credit_status VARCHAR(50), -- 'clean', 'restricted', 'negative'
    
    -- Consulta em Bureaus
    serasa_consulted BOOLEAN DEFAULT false,
    serasa_score INTEGER,
    serasa_consulted_at TIMESTAMP,
    
    spc_consulted BOOLEAN DEFAULT false,
    spc_status VARCHAR(50),
    spc_consulted_at TIMESTAMP,
    
    -- Restrições
    has_restrictions BOOLEAN DEFAULT false,
    restrictions_details JSONB, -- Array com detalhes das restrições
    total_debt DECIMAL(12, 2),
    
    -- Análise Financeira
    declared_income DECIMAL(12, 2),
    verified_income DECIMAL(12, 2),
    monthly_expenses DECIMAL(12, 2),
    monthly_commitments DECIMAL(12, 2), -- Compromissos financeiros existentes
    available_income DECIMAL(12, 2), -- Renda disponível
    debt_to_income_ratio DECIMAL(5, 2), -- Percentual de endividamento
    
    -- Capacidade de Pagamento
    max_installment_value DECIMAL(12, 2), -- Valor máximo de parcela
    max_property_value DECIMAL(12, 2), -- Valor máximo de imóvel
    down_payment_available DECIMAL(12, 2), -- Entrada disponível
    
    -- Resultado da Análise
    analysis_result VARCHAR(50), -- 'approved', 'approved_with_conditions', 'rejected'
    approval_conditions TEXT, -- Condições para aprovação
    rejection_reason TEXT,
    risk_level VARCHAR(20), -- 'low', 'medium', 'high'
    
    -- Recomendações
    recommended_property_value_min DECIMAL(12, 2),
    recommended_property_value_max DECIMAL(12, 2),
    recommended_down_payment_percentage DECIMAL(5, 2),
    recommended_financing_term INTEGER, -- Prazo em meses
    
    -- Observações
    analyst_notes TEXT,
    internal_notes TEXT,
    
    -- Controle
    analyzed_by UUID REFERENCES users(id),
    analyzed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    valid_until DATE, -- Validade da análise
    is_valid BOOLEAN GENERATED ALWAYS AS (valid_until >= CURRENT_DATE) STORED,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- TABELA: client_interests (Interesses em Empreendimentos)
-- ============================================
CREATE TABLE IF NOT EXISTS client_interests (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    client_id UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    property_id UUID REFERENCES properties(id),
    
    -- Interesse
    interest_level VARCHAR(20) DEFAULT 'medium', -- 'low', 'medium', 'high'
    interest_type VARCHAR(50), -- 'compra', 'aluguel'
    
    -- Preferências
    property_type VARCHAR(100), -- 'apartamento', 'casa', 'terreno', etc
    min_bedrooms INTEGER,
    min_bathrooms INTEGER,
    min_parking_spaces INTEGER,
    min_area DECIMAL(10, 2),
    
    -- Valores
    budget_min DECIMAL(12, 2),
    budget_max DECIMAL(12, 2),
    down_payment_available DECIMAL(12, 2),
    
    -- Localização
    preferred_neighborhoods TEXT[], -- Array de bairros
    preferred_cities TEXT[],
    
    -- Financiamento
    needs_financing BOOLEAN DEFAULT true,
    financing_type VARCHAR(100), -- 'SBPE', 'SFH', 'consórcio', 'à vista'
    bank_preference VARCHAR(255),
    
    -- Prazo
    desired_move_in_date DATE,
    urgency_level VARCHAR(20) DEFAULT 'medium', -- 'low', 'medium', 'high'
    
    -- Status
    status VARCHAR(50) DEFAULT 'active', -- 'active', 'paused', 'converted', 'cancelled'
    
    -- Notas
    notes TEXT,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- TABELA: document_checklist (Checklist de Documentos)
-- ============================================
CREATE TABLE IF NOT EXISTS document_checklist (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    client_id UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    
    -- Documento
    document_type VARCHAR(100) NOT NULL,
    document_name VARCHAR(255) NOT NULL,
    is_required BOOLEAN DEFAULT true,
    is_received BOOLEAN DEFAULT false,
    
    -- Status
    status VARCHAR(50) DEFAULT 'pending',
    -- 'pending', 'received', 'approved', 'rejected', 'not_applicable'
    
    -- Datas
    requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    received_at TIMESTAMP,
    approved_at TIMESTAMP,
    
    -- Observações
    notes TEXT,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- TABELA: financing_simulations (Simulações de Financiamento)
-- ============================================
CREATE TABLE IF NOT EXISTS financing_simulations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    client_id UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    property_id UUID REFERENCES properties(id),
    
    -- Valores
    property_value DECIMAL(12, 2) NOT NULL,
    down_payment DECIMAL(12, 2) NOT NULL,
    financed_amount DECIMAL(12, 2) NOT NULL,
    
    -- Condições
    interest_rate DECIMAL(5, 4) NOT NULL, -- Taxa de juros anual
    term_months INTEGER NOT NULL, -- Prazo em meses
    financing_system VARCHAR(50), -- 'SAC', 'PRICE', 'SAC + PRICE'
    
    -- Resultado
    monthly_installment DECIMAL(12, 2),
    total_amount DECIMAL(12, 2),
    total_interest DECIMAL(12, 2),
    
    -- Custos Adicionais
    insurance_value DECIMAL(12, 2),
    registration_fees DECIMAL(12, 2),
    other_fees DECIMAL(12, 2),
    
    -- Banco
    bank_name VARCHAR(255),
    bank_contact VARCHAR(255),
    
    -- Status
    status VARCHAR(50) DEFAULT 'draft', -- 'draft', 'sent_to_client', 'approved_by_client', 'sent_to_bank', 'approved_by_bank', 'rejected'
    
    -- Observações
    notes TEXT,
    
    -- Controle
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- ÍNDICES
-- ============================================

CREATE INDEX idx_clients_cpf ON clients(cpf);
CREATE INDEX idx_clients_status ON clients(registration_status);
CREATE INDEX idx_clients_assigned_to ON clients(assigned_to);
CREATE INDEX idx_clients_lead_id ON clients(lead_id);

CREATE INDEX idx_client_documents_client_id ON client_documents(client_id);
CREATE INDEX idx_client_documents_type ON client_documents(document_type);
CREATE INDEX idx_client_documents_status ON client_documents(status);

CREATE INDEX idx_credit_analysis_client_id ON credit_analysis(client_id);
CREATE INDEX idx_credit_analysis_result ON credit_analysis(analysis_result);
CREATE INDEX idx_credit_analysis_valid ON credit_analysis(is_valid);

CREATE INDEX idx_client_interests_client_id ON client_interests(client_id);
CREATE INDEX idx_client_interests_property_id ON client_interests(property_id);
CREATE INDEX idx_client_interests_status ON client_interests(status);

CREATE INDEX idx_document_checklist_client_id ON document_checklist(client_id);
CREATE INDEX idx_financing_simulations_client_id ON financing_simulations(client_id);

-- ============================================
-- TRIGGERS
-- ============================================

CREATE TRIGGER update_clients_updated_at BEFORE UPDATE ON clients FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_client_documents_updated_at BEFORE UPDATE ON client_documents FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_credit_analysis_updated_at BEFORE UPDATE ON credit_analysis FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_client_interests_updated_at BEFORE UPDATE ON client_interests FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_financing_simulations_updated_at BEFORE UPDATE ON financing_simulations FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Atualizar status do cliente baseado nos documentos
CREATE OR REPLACE FUNCTION update_client_status_from_documents()
RETURNS TRIGGER AS $$
DECLARE
    total_required INTEGER;
    total_approved INTEGER;
BEGIN
    -- Contar documentos obrigatórios
    SELECT COUNT(*) INTO total_required
    FROM document_checklist
    WHERE client_id = NEW.client_id AND is_required = true;
    
    -- Contar documentos aprovados
    SELECT COUNT(*) INTO total_approved
    FROM document_checklist
    WHERE client_id = NEW.client_id AND is_required = true AND status = 'approved';
    
    -- Atualizar status do cliente
    UPDATE clients
    SET registration_status = CASE
        WHEN total_approved = 0 THEN 'pending_docs'
        WHEN total_approved < total_required THEN 'pending_docs'
        WHEN total_approved = total_required THEN 'under_analysis'
    END
    WHERE id = NEW.client_id;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_client_status
AFTER INSERT OR UPDATE ON document_checklist
FOR EACH ROW
EXECUTE FUNCTION update_client_status_from_documents();

-- ============================================
-- VIEWS ÚTEIS
-- ============================================

-- View: Clientes com documentação pendente
CREATE OR REPLACE VIEW v_clients_pending_docs AS
SELECT 
    c.id,
    c.full_name,
    c.cpf,
    c.phone,
    c.email,
    c.registration_status,
    COUNT(dc.id) FILTER (WHERE dc.is_required = true) as total_required_docs,
    COUNT(dc.id) FILTER (WHERE dc.is_required = true AND dc.status = 'approved') as approved_docs,
    COUNT(dc.id) FILTER (WHERE dc.is_required = true AND dc.status = 'pending') as pending_docs,
    u.name as assigned_to_name
FROM clients c
LEFT JOIN document_checklist dc ON c.id = dc.client_id
LEFT JOIN users u ON c.assigned_to = u.id
WHERE c.registration_status IN ('incomplete', 'pending_docs')
GROUP BY c.id, c.full_name, c.cpf, c.phone, c.email, c.registration_status, u.name;

-- View: Clientes aprovados com interesse ativo
CREATE OR REPLACE VIEW v_approved_clients_with_interest AS
SELECT 
    c.id,
    c.full_name,
    c.cpf,
    c.phone,
    c.monthly_income,
    ca.credit_score,
    ca.analysis_result,
    ca.max_property_value,
    ci.budget_min,
    ci.budget_max,
    ci.property_type,
    ci.urgency_level,
    u.name as assigned_to_name
FROM clients c
INNER JOIN credit_analysis ca ON c.id = ca.client_id AND ca.is_valid = true
INNER JOIN client_interests ci ON c.id = ci.client_id AND ci.status = 'active'
LEFT JOIN users u ON c.assigned_to = u.id
WHERE ca.analysis_result IN ('approved', 'approved_with_conditions')
ORDER BY ci.urgency_level DESC, ca.credit_score DESC;

-- View: Resumo de análises de crédito
CREATE OR REPLACE VIEW v_credit_analysis_summary AS
SELECT 
    analysis_result,
    COUNT(*) as total,
    AVG(credit_score) as avg_score,
    AVG(max_property_value) as avg_max_property_value,
    AVG(debt_to_income_ratio) as avg_debt_ratio
FROM credit_analysis
WHERE is_valid = true
GROUP BY analysis_result;

-- ============================================
-- FUNÇÃO: Criar checklist padrão de documentos
-- ============================================
CREATE OR REPLACE FUNCTION create_default_document_checklist(p_client_id UUID)
RETURNS VOID AS $$
BEGIN
    INSERT INTO document_checklist (client_id, document_type, document_name, is_required) VALUES
    (p_client_id, 'rg_frente', 'RG - Frente', true),
    (p_client_id, 'rg_verso', 'RG - Verso', true),
    (p_client_id, 'cpf', 'CPF', true),
    (p_client_id, 'comprovante_residencia', 'Comprovante de Residência (últimos 3 meses)', true),
    (p_client_id, 'comprovante_renda', 'Comprovante de Renda (últimos 3 meses)', true),
    (p_client_id, 'ctps', 'CTPS - Carteira de Trabalho', true),
    (p_client_id, 'extrato_bancario', 'Extrato Bancário (últimos 3 meses)', true),
    (p_client_id, 'ir', 'Imposto de Renda (última declaração)', false),
    (p_client_id, 'certidao_casamento', 'Certidão de Casamento', false),
    (p_client_id, 'certidao_nascimento', 'Certidão de Nascimento', false);
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- FUNÇÃO: Calcular capacidade de pagamento
-- ============================================
CREATE OR REPLACE FUNCTION calculate_payment_capacity(
    p_monthly_income DECIMAL,
    p_monthly_expenses DECIMAL,
    p_monthly_commitments DECIMAL,
    p_max_commitment_percentage DECIMAL DEFAULT 30.00
)
RETURNS TABLE (
    available_income DECIMAL,
    max_installment DECIMAL,
    max_property_value DECIMAL,
    debt_to_income_ratio DECIMAL
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        (p_monthly_income - p_monthly_expenses - p_monthly_commitments) as available_income,
        ((p_monthly_income * p_max_commitment_percentage / 100) - p_monthly_commitments) as max_installment,
        (((p_monthly_income * p_max_commitment_percentage / 100) - p_monthly_commitments) * 120) as max_property_value, -- Estimativa 120x parcela
        CASE 
            WHEN p_monthly_income > 0 
            THEN ROUND(((p_monthly_expenses + p_monthly_commitments) / p_monthly_income * 100), 2)
            ELSE 0
        END as debt_to_income_ratio;
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- FIM DO MÓDULO DE CADASTRO DE CLIENTES
-- ============================================
