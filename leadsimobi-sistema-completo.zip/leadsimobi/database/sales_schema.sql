-- ============================================
-- MÓDULO DE VENDAS E COMISSÕES
-- Sistema de controle financeiro para corretores
-- ============================================

-- ============================================
-- TABELA: sales (Vendas Realizadas)
-- ============================================
CREATE TABLE IF NOT EXISTS sales (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    -- Relacionamentos
    lead_id UUID REFERENCES leads(id),
    property_id UUID REFERENCES properties(id),
    agent_id UUID NOT NULL REFERENCES users(id), -- Corretor responsável
    
    -- Informações da venda
    sale_type VARCHAR(50) NOT NULL, -- 'venda', 'aluguel', 'permuta'
    sale_value DECIMAL(12, 2) NOT NULL, -- Valor total da venda
    
    -- Comissão
    commission_percentage DECIMAL(5, 2) NOT NULL, -- Ex: 6.00 para 6%
    commission_value DECIMAL(12, 2) NOT NULL, -- Valor calculado da comissão
    commission_split JSONB, -- Divisão de comissão entre múltiplos agentes
    
    -- Status da comissão
    commission_status VARCHAR(50) DEFAULT 'pending', -- 'pending', 'partial', 'paid'
    commission_paid_value DECIMAL(12, 2) DEFAULT 0, -- Valor já pago
    commission_paid_date DATE,
    
    -- Datas importantes
    sale_date DATE NOT NULL, -- Data da venda
    contract_date DATE, -- Data do contrato
    expected_payment_date DATE, -- Previsão de recebimento
    
    -- Detalhes adicionais
    payment_method VARCHAR(100), -- 'financiamento', 'à vista', 'consórcio'
    bank VARCHAR(255), -- Banco do financiamento
    notes TEXT,
    contract_number VARCHAR(100),
    
    -- Anexos
    documents JSONB, -- Array de URLs de documentos (contrato, etc)
    
    -- Controle
    is_cancelled BOOLEAN DEFAULT false,
    cancellation_reason TEXT,
    cancelled_at TIMESTAMP,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- TABELA: commission_payments (Pagamentos de Comissão)
-- ============================================
CREATE TABLE IF NOT EXISTS commission_payments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sale_id UUID NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
    agent_id UUID NOT NULL REFERENCES users(id),
    
    -- Pagamento
    payment_value DECIMAL(12, 2) NOT NULL,
    payment_date DATE NOT NULL,
    payment_method VARCHAR(100), -- 'transferência', 'dinheiro', 'cheque', 'pix'
    
    -- Referência
    transaction_reference VARCHAR(255), -- Número do comprovante, cheque, etc
    notes TEXT,
    
    -- Anexos
    receipt_url TEXT, -- URL do comprovante
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by UUID REFERENCES users(id)
);

-- ============================================
-- TABELA: sales_goals (Metas de Vendas)
-- ============================================
CREATE TABLE IF NOT EXISTS sales_goals (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    agent_id UUID REFERENCES users(id), -- NULL = meta geral da empresa
    
    -- Período
    period_type VARCHAR(20) NOT NULL, -- 'monthly', 'quarterly', 'yearly'
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    
    -- Metas
    target_sales_count INTEGER, -- Número de vendas
    target_sales_value DECIMAL(12, 2), -- Valor total em vendas
    target_commission_value DECIMAL(12, 2), -- Valor em comissões
    
    -- Progresso (calculado)
    current_sales_count INTEGER DEFAULT 0,
    current_sales_value DECIMAL(12, 2) DEFAULT 0,
    current_commission_value DECIMAL(12, 2) DEFAULT 0,
    
    -- Controle
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- TABELA: expenses (Despesas)
-- ============================================
CREATE TABLE IF NOT EXISTS expenses (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    -- Relacionamentos
    agent_id UUID REFERENCES users(id),
    sale_id UUID REFERENCES sales(id), -- Despesa relacionada a uma venda específica
    
    -- Informações da despesa
    category VARCHAR(100) NOT NULL, -- 'marketing', 'transporte', 'documentação', 'outros'
    description TEXT NOT NULL,
    amount DECIMAL(12, 2) NOT NULL,
    
    -- Data
    expense_date DATE NOT NULL,
    
    -- Pagamento
    payment_method VARCHAR(100),
    is_reimbursable BOOLEAN DEFAULT false, -- Se pode ser reembolsado
    reimbursement_status VARCHAR(50) DEFAULT 'pending', -- 'pending', 'approved', 'paid', 'rejected'
    reimbursed_at TIMESTAMP,
    
    -- Anexos
    receipt_url TEXT,
    
    -- Controle
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by UUID REFERENCES users(id)
);

-- ============================================
-- ÍNDICES PARA PERFORMANCE
-- ============================================

CREATE INDEX idx_sales_agent_id ON sales(agent_id);
CREATE INDEX idx_sales_sale_date ON sales(sale_date DESC);
CREATE INDEX idx_sales_commission_status ON sales(commission_status);
CREATE INDEX idx_sales_lead_id ON sales(lead_id);
CREATE INDEX idx_sales_property_id ON sales(property_id);

CREATE INDEX idx_commission_payments_sale_id ON commission_payments(sale_id);
CREATE INDEX idx_commission_payments_agent_id ON commission_payments(agent_id);
CREATE INDEX idx_commission_payments_date ON commission_payments(payment_date DESC);

CREATE INDEX idx_sales_goals_agent_id ON sales_goals(agent_id);
CREATE INDEX idx_sales_goals_period ON sales_goals(period_start, period_end);

CREATE INDEX idx_expenses_agent_id ON expenses(agent_id);
CREATE INDEX idx_expenses_date ON expenses(expense_date DESC);
CREATE INDEX idx_expenses_category ON expenses(category);

-- ============================================
-- TRIGGERS
-- ============================================

-- Atualizar updated_at
CREATE TRIGGER update_sales_updated_at BEFORE UPDATE ON sales FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_sales_goals_updated_at BEFORE UPDATE ON sales_goals FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Calcular valor da comissão automaticamente
CREATE OR REPLACE FUNCTION calculate_commission_value()
RETURNS TRIGGER AS $$
BEGIN
    NEW.commission_value = (NEW.sale_value * NEW.commission_percentage / 100);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_calculate_commission
BEFORE INSERT OR UPDATE OF sale_value, commission_percentage ON sales
FOR EACH ROW
EXECUTE FUNCTION calculate_commission_value();

-- Atualizar status da comissão quando houver pagamento
CREATE OR REPLACE FUNCTION update_commission_status()
RETURNS TRIGGER AS $$
DECLARE
    total_paid DECIMAL(12, 2);
    sale_commission DECIMAL(12, 2);
BEGIN
    -- Calcular total pago
    SELECT COALESCE(SUM(payment_value), 0) INTO total_paid
    FROM commission_payments
    WHERE sale_id = NEW.sale_id;
    
    -- Buscar valor da comissão
    SELECT commission_value INTO sale_commission
    FROM sales
    WHERE id = NEW.sale_id;
    
    -- Atualizar status
    UPDATE sales
    SET 
        commission_paid_value = total_paid,
        commission_status = CASE
            WHEN total_paid >= sale_commission THEN 'paid'
            WHEN total_paid > 0 THEN 'partial'
            ELSE 'pending'
        END,
        commission_paid_date = CASE
            WHEN total_paid >= sale_commission THEN CURRENT_DATE
            ELSE NULL
        END
    WHERE id = NEW.sale_id;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_commission_status
AFTER INSERT OR UPDATE OR DELETE ON commission_payments
FOR EACH ROW
EXECUTE FUNCTION update_commission_status();

-- ============================================
-- VIEWS ÚTEIS
-- ============================================

-- View: Resumo financeiro por agente
CREATE OR REPLACE VIEW v_agent_financial_summary AS
SELECT 
    u.id as agent_id,
    u.name as agent_name,
    COUNT(s.id) as total_sales,
    SUM(s.sale_value) as total_sales_value,
    SUM(s.commission_value) as total_commission,
    SUM(s.commission_paid_value) as commission_received,
    SUM(s.commission_value - s.commission_paid_value) as commission_pending,
    COALESCE(SUM(e.amount), 0) as total_expenses,
    SUM(s.commission_paid_value) - COALESCE(SUM(e.amount), 0) as net_income
FROM users u
LEFT JOIN sales s ON u.id = s.agent_id AND s.is_cancelled = false
LEFT JOIN expenses e ON u.id = e.agent_id
WHERE u.role = 'agent'
GROUP BY u.id, u.name;

-- View: Vendas do mês atual
CREATE OR REPLACE VIEW v_current_month_sales AS
SELECT 
    s.*,
    u.name as agent_name,
    l.name as client_name,
    p.title as property_title
FROM sales s
LEFT JOIN users u ON s.agent_id = u.id
LEFT JOIN leads l ON s.lead_id = l.id
LEFT JOIN properties p ON s.property_id = p.id
WHERE s.sale_date >= DATE_TRUNC('month', CURRENT_DATE)
  AND s.sale_date < DATE_TRUNC('month', CURRENT_DATE) + INTERVAL '1 month'
  AND s.is_cancelled = false
ORDER BY s.sale_date DESC;

-- View: Ranking de vendedores
CREATE OR REPLACE VIEW v_sales_ranking AS
SELECT 
    u.id as agent_id,
    u.name as agent_name,
    u.avatar_url,
    COUNT(s.id) as sales_count,
    SUM(s.sale_value) as total_value,
    SUM(s.commission_value) as total_commission,
    ROUND(AVG(s.sale_value), 2) as avg_sale_value,
    ROW_NUMBER() OVER (ORDER BY SUM(s.sale_value) DESC) as rank
FROM users u
LEFT JOIN sales s ON u.id = s.agent_id 
    AND s.sale_date >= DATE_TRUNC('month', CURRENT_DATE)
    AND s.is_cancelled = false
WHERE u.role = 'agent' AND u.is_active = true
GROUP BY u.id, u.name, u.avatar_url
ORDER BY total_value DESC;

-- View: Comissões a receber
CREATE OR REPLACE VIEW v_pending_commissions AS
SELECT 
    s.id as sale_id,
    s.sale_date,
    s.expected_payment_date,
    s.sale_value,
    s.commission_value,
    s.commission_paid_value,
    (s.commission_value - s.commission_paid_value) as pending_amount,
    s.commission_status,
    u.name as agent_name,
    l.name as client_name,
    p.title as property_title
FROM sales s
LEFT JOIN users u ON s.agent_id = u.id
LEFT JOIN leads l ON s.lead_id = l.id
LEFT JOIN properties p ON s.property_id = p.id
WHERE s.commission_status IN ('pending', 'partial')
  AND s.is_cancelled = false
ORDER BY s.expected_payment_date ASC NULLS LAST;

-- View: Performance vs Meta
CREATE OR REPLACE VIEW v_goals_performance AS
SELECT 
    sg.id as goal_id,
    sg.agent_id,
    u.name as agent_name,
    sg.period_type,
    sg.period_start,
    sg.period_end,
    sg.target_sales_count,
    sg.target_sales_value,
    sg.target_commission_value,
    COUNT(s.id) as current_sales_count,
    COALESCE(SUM(s.sale_value), 0) as current_sales_value,
    COALESCE(SUM(s.commission_value), 0) as current_commission_value,
    CASE 
        WHEN sg.target_sales_count > 0 
        THEN ROUND((COUNT(s.id)::DECIMAL / sg.target_sales_count * 100), 2)
        ELSE 0
    END as sales_count_percentage,
    CASE 
        WHEN sg.target_sales_value > 0 
        THEN ROUND((COALESCE(SUM(s.sale_value), 0) / sg.target_sales_value * 100), 2)
        ELSE 0
    END as sales_value_percentage
FROM sales_goals sg
LEFT JOIN users u ON sg.agent_id = u.id
LEFT JOIN sales s ON s.agent_id = sg.agent_id 
    AND s.sale_date BETWEEN sg.period_start AND sg.period_end
    AND s.is_cancelled = false
WHERE sg.is_active = true
GROUP BY sg.id, sg.agent_id, u.name, sg.period_type, sg.period_start, sg.period_end, 
         sg.target_sales_count, sg.target_sales_value, sg.target_commission_value;

-- ============================================
-- FUNÇÃO: Relatório financeiro mensal
-- ============================================
CREATE OR REPLACE FUNCTION get_monthly_financial_report(
    p_agent_id UUID DEFAULT NULL,
    p_month DATE DEFAULT CURRENT_DATE
)
RETURNS TABLE (
    period_start DATE,
    period_end DATE,
    total_sales BIGINT,
    total_sales_value NUMERIC,
    total_commission NUMERIC,
    commission_received NUMERIC,
    commission_pending NUMERIC,
    total_expenses NUMERIC,
    net_income NUMERIC,
    avg_ticket NUMERIC
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        DATE_TRUNC('month', p_month)::DATE as period_start,
        (DATE_TRUNC('month', p_month) + INTERVAL '1 month - 1 day')::DATE as period_end,
        COUNT(s.id) as total_sales,
        COALESCE(SUM(s.sale_value), 0) as total_sales_value,
        COALESCE(SUM(s.commission_value), 0) as total_commission,
        COALESCE(SUM(s.commission_paid_value), 0) as commission_received,
        COALESCE(SUM(s.commission_value - s.commission_paid_value), 0) as commission_pending,
        COALESCE(SUM(e.amount), 0) as total_expenses,
        COALESCE(SUM(s.commission_paid_value), 0) - COALESCE(SUM(e.amount), 0) as net_income,
        CASE 
            WHEN COUNT(s.id) > 0 
            THEN ROUND(SUM(s.sale_value) / COUNT(s.id), 2)
            ELSE 0
        END as avg_ticket
    FROM sales s
    LEFT JOIN expenses e ON e.agent_id = s.agent_id 
        AND e.expense_date BETWEEN DATE_TRUNC('month', p_month) 
        AND (DATE_TRUNC('month', p_month) + INTERVAL '1 month - 1 day')
    WHERE s.sale_date BETWEEN DATE_TRUNC('month', p_month) 
        AND (DATE_TRUNC('month', p_month) + INTERVAL '1 month - 1 day')
      AND s.is_cancelled = false
      AND (p_agent_id IS NULL OR s.agent_id = p_agent_id);
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- FIM DO MÓDULO DE VENDAS
-- ============================================
