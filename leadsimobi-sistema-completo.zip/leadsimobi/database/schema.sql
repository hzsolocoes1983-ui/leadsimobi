-- ============================================
-- SCHEMA DO CRM LEADSIMOBI
-- Sistema de gestão de leads com WhatsApp e Instagram
-- ============================================

-- Extensões necessárias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm"; -- Para busca full-text

-- ============================================
-- TABELA: users (Usuários/Corretores)
-- ============================================
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(50) DEFAULT 'agent', -- 'admin', 'agent', 'manager'
    avatar_url TEXT,
    phone VARCHAR(20),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- TABELA: channels (Canais de Comunicação)
-- ============================================
CREATE TABLE IF NOT EXISTS channels (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    type VARCHAR(50) NOT NULL, -- 'whatsapp', 'instagram', 'telegram', 'email'
    instance_id VARCHAR(255), -- ID da instância no Evolution API
    phone_number VARCHAR(20), -- Para WhatsApp
    instagram_username VARCHAR(100), -- Para Instagram
    is_active BOOLEAN DEFAULT true,
    config JSONB, -- Configurações específicas do canal
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- TABELA: leads (Leads/Clientes)
-- ============================================
CREATE TABLE IF NOT EXISTS leads (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255),
    phone VARCHAR(20),
    instagram_username VARCHAR(100),
    
    -- Origem do lead
    source VARCHAR(100), -- 'whatsapp', 'instagram', 'website', 'referral', 'manual'
    channel_id UUID REFERENCES channels(id),
    
    -- Status no funil
    status VARCHAR(50) DEFAULT 'new', -- 'new', 'contacted', 'qualified', 'proposal', 'negotiation', 'won', 'lost'
    stage VARCHAR(100), -- Estágio personalizado no funil
    
    -- Pontuação e qualificação
    score INTEGER DEFAULT 0, -- Score de qualificação (0-100)
    temperature VARCHAR(20) DEFAULT 'cold', -- 'cold', 'warm', 'hot'
    
    -- Informações de interesse
    interest_type VARCHAR(100), -- 'compra', 'venda', 'aluguel'
    property_type VARCHAR(100), -- 'apartamento', 'casa', 'terreno', etc
    budget_min DECIMAL(12, 2),
    budget_max DECIMAL(12, 2),
    location_preference TEXT,
    
    -- Responsável
    assigned_to UUID REFERENCES users(id),
    
    -- Metadados
    tags TEXT[], -- Array de tags
    notes TEXT,
    custom_fields JSONB, -- Campos personalizados
    
    -- Controle
    last_contact_at TIMESTAMP,
    next_followup_at TIMESTAMP,
    is_active BOOLEAN DEFAULT true,
    lost_reason TEXT,
    won_value DECIMAL(12, 2),
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- TABELA: interactions (Interações/Histórico)
-- ============================================
CREATE TABLE IF NOT EXISTS interactions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    lead_id UUID NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id),
    channel_id UUID REFERENCES channels(id),
    
    -- Tipo de interação
    type VARCHAR(50) NOT NULL, -- 'message', 'call', 'email', 'meeting', 'note', 'status_change'
    direction VARCHAR(20), -- 'inbound', 'outbound'
    
    -- Conteúdo
    subject VARCHAR(255),
    content TEXT,
    metadata JSONB, -- Dados adicionais (ex: ID da mensagem no WhatsApp)
    
    -- Anexos
    attachments JSONB, -- Array de URLs de arquivos
    
    -- Controle
    is_automated BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- TABELA: messages (Mensagens de WhatsApp/Instagram)
-- ============================================
CREATE TABLE IF NOT EXISTS messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    interaction_id UUID REFERENCES interactions(id) ON DELETE CASCADE,
    lead_id UUID NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
    channel_id UUID NOT NULL REFERENCES channels(id),
    
    -- Identificadores externos
    external_id VARCHAR(255), -- ID da mensagem no Evolution API
    remote_jid VARCHAR(255), -- JID do contato (WhatsApp/Instagram)
    
    -- Conteúdo
    message_type VARCHAR(50), -- 'text', 'image', 'video', 'audio', 'document', 'location'
    content TEXT,
    media_url TEXT,
    caption TEXT,
    
    -- Direção e status
    direction VARCHAR(20) NOT NULL, -- 'inbound', 'outbound'
    status VARCHAR(50), -- 'pending', 'sent', 'delivered', 'read', 'failed'
    
    -- Metadados
    metadata JSONB,
    
    -- Timestamps
    sent_at TIMESTAMP,
    delivered_at TIMESTAMP,
    read_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- TABELA: pipeline_stages (Estágios do Funil)
-- ============================================
CREATE TABLE IF NOT EXISTS pipeline_stages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    description TEXT,
    order_index INTEGER NOT NULL,
    color VARCHAR(20), -- Cor hex para visualização
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- TABELA: automations (Automações)
-- ============================================
CREATE TABLE IF NOT EXISTS automations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    trigger_type VARCHAR(100) NOT NULL, -- 'new_lead', 'status_change', 'no_contact', 'scheduled'
    trigger_config JSONB,
    
    -- Ação
    action_type VARCHAR(100) NOT NULL, -- 'send_message', 'assign_user', 'change_status', 'create_task'
    action_config JSONB,
    
    -- Controle
    is_active BOOLEAN DEFAULT true,
    execution_count INTEGER DEFAULT 0,
    last_executed_at TIMESTAMP,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- TABELA: tasks (Tarefas/Lembretes)
-- ============================================
CREATE TABLE IF NOT EXISTS tasks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    lead_id UUID REFERENCES leads(id) ON DELETE CASCADE,
    assigned_to UUID REFERENCES users(id),
    created_by UUID REFERENCES users(id),
    
    title VARCHAR(255) NOT NULL,
    description TEXT,
    type VARCHAR(50), -- 'call', 'meeting', 'follow_up', 'email', 'other'
    priority VARCHAR(20) DEFAULT 'medium', -- 'low', 'medium', 'high', 'urgent'
    status VARCHAR(50) DEFAULT 'pending', -- 'pending', 'in_progress', 'completed', 'cancelled'
    
    due_date TIMESTAMP,
    completed_at TIMESTAMP,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- TABELA: properties (Imóveis)
-- ============================================
CREATE TABLE IF NOT EXISTS properties (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title VARCHAR(255) NOT NULL,
    description TEXT,
    type VARCHAR(100), -- 'apartamento', 'casa', 'terreno', etc
    transaction_type VARCHAR(50), -- 'venda', 'aluguel', 'ambos'
    
    -- Localização
    address TEXT,
    neighborhood VARCHAR(255),
    city VARCHAR(255),
    state VARCHAR(2),
    zip_code VARCHAR(20),
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    
    -- Características
    bedrooms INTEGER,
    bathrooms INTEGER,
    parking_spaces INTEGER,
    area_total DECIMAL(10, 2),
    area_useful DECIMAL(10, 2),
    
    -- Valores
    price DECIMAL(12, 2),
    rental_price DECIMAL(12, 2),
    condo_fee DECIMAL(12, 2),
    iptu DECIMAL(12, 2),
    
    -- Mídia
    images JSONB, -- Array de URLs
    video_url TEXT,
    virtual_tour_url TEXT,
    
    -- Controle
    is_active BOOLEAN DEFAULT true,
    featured BOOLEAN DEFAULT false,
    owner_id UUID REFERENCES users(id),
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- TABELA: lead_properties (Relação Lead-Imóvel)
-- ============================================
CREATE TABLE IF NOT EXISTS lead_properties (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    lead_id UUID NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
    property_id UUID NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
    interest_level VARCHAR(20), -- 'low', 'medium', 'high'
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(lead_id, property_id)
);

-- ============================================
-- TABELA: campaigns (Campanhas de Marketing)
-- ============================================
CREATE TABLE IF NOT EXISTS campaigns (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    type VARCHAR(50), -- 'whatsapp_broadcast', 'instagram_story', 'email'
    channel_id UUID REFERENCES channels(id),
    
    -- Configuração
    message_template TEXT,
    target_filters JSONB, -- Filtros para selecionar leads
    
    -- Métricas
    total_sent INTEGER DEFAULT 0,
    total_delivered INTEGER DEFAULT 0,
    total_read INTEGER DEFAULT 0,
    total_replied INTEGER DEFAULT 0,
    
    -- Controle
    status VARCHAR(50) DEFAULT 'draft', -- 'draft', 'scheduled', 'running', 'completed', 'cancelled'
    scheduled_at TIMESTAMP,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- ÍNDICES PARA PERFORMANCE
-- ============================================

-- Leads
CREATE INDEX idx_leads_status ON leads(status);
CREATE INDEX idx_leads_assigned_to ON leads(assigned_to);
CREATE INDEX idx_leads_source ON leads(source);
CREATE INDEX idx_leads_phone ON leads(phone);
CREATE INDEX idx_leads_email ON leads(email);
CREATE INDEX idx_leads_created_at ON leads(created_at DESC);
CREATE INDEX idx_leads_next_followup ON leads(next_followup_at) WHERE next_followup_at IS NOT NULL;
CREATE INDEX idx_leads_search ON leads USING gin(to_tsvector('portuguese', name || ' ' || COALESCE(email, '') || ' ' || COALESCE(phone, '')));

-- Interactions
CREATE INDEX idx_interactions_lead_id ON interactions(lead_id);
CREATE INDEX idx_interactions_created_at ON interactions(created_at DESC);
CREATE INDEX idx_interactions_type ON interactions(type);

-- Messages
CREATE INDEX idx_messages_lead_id ON messages(lead_id);
CREATE INDEX idx_messages_channel_id ON messages(channel_id);
CREATE INDEX idx_messages_external_id ON messages(external_id);
CREATE INDEX idx_messages_created_at ON messages(created_at DESC);

-- Tasks
CREATE INDEX idx_tasks_assigned_to ON tasks(assigned_to);
CREATE INDEX idx_tasks_lead_id ON tasks(lead_id);
CREATE INDEX idx_tasks_due_date ON tasks(due_date) WHERE status != 'completed';
CREATE INDEX idx_tasks_status ON tasks(status);

-- Properties
CREATE INDEX idx_properties_type ON properties(type);
CREATE INDEX idx_properties_city ON properties(city);
CREATE INDEX idx_properties_price ON properties(price);
CREATE INDEX idx_properties_is_active ON properties(is_active);

-- ============================================
-- TRIGGERS PARA ATUALIZAÇÃO AUTOMÁTICA
-- ============================================

-- Função para atualizar updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Aplicar trigger em todas as tabelas relevantes
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_channels_updated_at BEFORE UPDATE ON channels FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_leads_updated_at BEFORE UPDATE ON leads FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_pipeline_stages_updated_at BEFORE UPDATE ON pipeline_stages FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_automations_updated_at BEFORE UPDATE ON automations FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_tasks_updated_at BEFORE UPDATE ON tasks FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_properties_updated_at BEFORE UPDATE ON properties FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_campaigns_updated_at BEFORE UPDATE ON campaigns FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- DADOS INICIAIS (SEED)
-- ============================================

-- Estágios padrão do funil
INSERT INTO pipeline_stages (name, description, order_index, color) VALUES
('Novo Lead', 'Lead acabou de entrar no sistema', 1, '#3B82F6'),
('Contato Inicial', 'Primeiro contato realizado', 2, '#8B5CF6'),
('Qualificado', 'Lead qualificado e interessado', 3, '#10B981'),
('Visita Agendada', 'Visita ao imóvel agendada', 4, '#F59E0B'),
('Proposta Enviada', 'Proposta comercial enviada', 5, '#EF4444'),
('Negociação', 'Em processo de negociação', 6, '#EC4899'),
('Fechado - Ganho', 'Venda concluída com sucesso', 7, '#22C55E'),
('Fechado - Perdido', 'Lead perdido', 8, '#6B7280')
ON CONFLICT DO NOTHING;

-- Usuário admin padrão (senha: admin123)
INSERT INTO users (name, email, password_hash, role) VALUES
('Administrador', 'admin@leadsimobi.com', '$2a$10$rOzJQjYzjJKxMxqKV.Qg8.vF5v5F5v5F5v5F5v5F5v5F5v5F5v5F5', 'admin')
ON CONFLICT (email) DO NOTHING;

-- ============================================
-- VIEWS ÚTEIS
-- ============================================

-- View: Resumo de leads por estágio
CREATE OR REPLACE VIEW v_leads_by_stage AS
SELECT 
    ps.name as stage_name,
    ps.color,
    COUNT(l.id) as lead_count,
    SUM(CASE WHEN l.temperature = 'hot' THEN 1 ELSE 0 END) as hot_leads,
    AVG(l.score) as avg_score
FROM pipeline_stages ps
LEFT JOIN leads l ON l.stage = ps.name AND l.is_active = true
GROUP BY ps.id, ps.name, ps.color, ps.order_index
ORDER BY ps.order_index;

-- View: Leads com próximo follow-up
CREATE OR REPLACE VIEW v_upcoming_followups AS
SELECT 
    l.id,
    l.name,
    l.phone,
    l.status,
    l.next_followup_at,
    u.name as assigned_to_name,
    l.last_contact_at
FROM leads l
LEFT JOIN users u ON l.assigned_to = u.id
WHERE l.next_followup_at IS NOT NULL
  AND l.next_followup_at >= CURRENT_TIMESTAMP
  AND l.is_active = true
ORDER BY l.next_followup_at ASC;

-- View: Métricas de conversão
CREATE OR REPLACE VIEW v_conversion_metrics AS
SELECT 
    COUNT(*) FILTER (WHERE status = 'new') as new_leads,
    COUNT(*) FILTER (WHERE status = 'contacted') as contacted_leads,
    COUNT(*) FILTER (WHERE status = 'qualified') as qualified_leads,
    COUNT(*) FILTER (WHERE status = 'won') as won_leads,
    COUNT(*) FILTER (WHERE status = 'lost') as lost_leads,
    ROUND(
        (COUNT(*) FILTER (WHERE status = 'won')::DECIMAL / 
        NULLIF(COUNT(*) FILTER (WHERE status IN ('won', 'lost')), 0)) * 100, 
        2
    ) as conversion_rate,
    SUM(won_value) as total_revenue
FROM leads
WHERE created_at >= CURRENT_DATE - INTERVAL '30 days';

-- ============================================
-- FIM DO SCHEMA
-- ============================================
